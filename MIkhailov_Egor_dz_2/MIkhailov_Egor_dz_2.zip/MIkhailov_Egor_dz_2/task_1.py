l = [1, 2.3, 'text', {2, True}, [2, 5, 8, ], {'q': 10, 'w': 5},('heelo','wold')]
for elem in l:
    print(elem,type(elem))
