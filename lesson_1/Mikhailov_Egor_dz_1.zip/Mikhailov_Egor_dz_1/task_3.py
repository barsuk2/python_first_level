# my_num=(input('Введите число '))
my_num= '4'
# print(f'{int(my_num)} + {int(my_num + my_num)} + {int(my_num + my_num + my_num)}')
my_summ= int(my_num) + int(my_num + my_num) + int(my_num + my_num + my_num)
print(my_summ)